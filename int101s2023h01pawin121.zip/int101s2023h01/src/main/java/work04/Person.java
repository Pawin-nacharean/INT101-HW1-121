/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package work04;

public class Person {
    
    private int id;

    // Constructor to set the id field
    public Person(int id) {
        this.id = id;
    }

    // Getter method for the id field
    public int getId() {
        return id;
    }

    // Setter method for the id field
    public void setId(int id) {
        this.id = id;
    }

    // Override the toString method
    @Override
    public String toString() {
        return "Person(" + id + ")";
    }
}


